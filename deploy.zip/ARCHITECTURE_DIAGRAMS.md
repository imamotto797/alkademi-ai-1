# Architecture Diagram & Visual Guide

## 1. Frontend Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        index.html (150 lines)                   │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │         Header (Alkademi AI + Quota Status)              │  │
│  ├──────────────────────────────────────────────────────────┤  │
│  │  Tab Navigation: Upload | Generate | Materials | Analytics  │
│  ├──────────────────────────────────────────────────────────┤  │
│  │  Dynamic Tab Container (4 content areas)                 │  │
│  │  ┌──────────────┬──────────────┬──────────────┬─────────┐ │
│  │  │ Upload-      │ Generate-    │ Materials-   │ Analytics│ │
│  │  │ Container    │ Container    │ Container    │ Container│ │
│  │  └──────────────┴──────────────┴──────────────┴─────────┘ │
│  ├──────────────────────────────────────────────────────────┤  │
│  │                    Footer (Copyright)                    │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
│                   Scripts Loading Order:                        │
│                   1. utils.js (utilities)                       │
│                   2. api.js (API manager)                       │
│                   3. Module files                               │
│                   4. AppController (main logic)                 │
└─────────────────────────────────────────────────────────────────┘
```

## 2. Module Architecture

```
┌────────────────────────────────────────────────────────────┐
│                    AppController                           │
│  - Loads HTML partials dynamically                         │
│  - Manages tab switching                                   │
│  - Refreshes quota status                                  │
└────────────┬───────────────────────────────────────────────┘
             │
    ┌────────┼────────┬────────────┬──────────────┐
    │        │        │            │              │
    ▼        ▼        ▼            ▼              ▼
┌────────┐ ┌──────┐ ┌────────┐ ┌──────────┐ ┌────────────┐
│Upload  │ │Gener-│ │Materi- │ │Analytics │ │API Manager │
│Module  │ │ateM. │ │als M.  │ │Module    │ │(Shared)    │
│        │ │      │ │        │ │          │ │            │
│ Form   │ │Gen.  │ │List    │ │Dashboard │ │- Request() │
│Upload  │ │Type  │ │Search  │ │Stats     │ │- Upload()  │
│Progress│ │Prov. │ │Modal   │ │Export    │ │- Generate()│
└────────┘ └──────┘ └────────┘ └──────────┘ │- Analytics │
    │        │        │            │         │  Methods   │
    └────────┼────────┼────────────┼─────────┘ └────────────┘
             │        │            │              │
             └────────┴────────────┴──────────────┘
                      │
            ┌─────────▼──────────┐
            │   Shared Utils.js   │
            │ - Notification      │
            │ - DOM helpers       │
            │ - DateFormatter     │
            │ - DataFormatter     │
            │ - Storage           │
            └─────────┬───────────┘
                      │
         ┌────────────▼────────────┐
         │  Backend Express API    │
         │                         │
         │  Routes:                │
         │  /materials/*           │
         │  /analytics/*           │
         └────────────┬────────────┘
                      │
         ┌────────────▼────────────┐
         │  PostgreSQL Database    │
         │                         │
         │  Tables:                │
         │  - materials            │
         │  - access_logs          │
         │  - downloads            │
         │  - feedback             │
         └─────────────────────────┘
```

## 3. Data Flow Diagram

```
User Action
    │
    ├─────────────────────────────────────────┐
    │                                         │
    ▼                                         ▼
Upload File                            Generate Content
    │                                         │
    ├─ File Validation (size, type)          ├─ Material Selection
    │                                         ├─ Provider Selection
    ├─ FormData Creation                      ├─ Options Configuration
    │                                         │
    ▼                                         ▼
api.uploadCombinedMaterials()      api.generateMaterials()
    │                                         │
    └─────────────────┬───────────────────────┘
                      │
             ┌────────▼────────┐
             │  APIManager     │
             │  - fetch()      │
             │  - Error handle │
             │  - JSON parse   │
             └────────┬────────┘
                      │
         ┌────────────▼────────────┐
         │  Backend Express        │
         │                         │
         │  Controller:            │
         │  - File processing      │
         │  - LLM Service call     │
         │  - DB operations        │
         └────────┬────────────────┘
                  │
    ┌─────────────┼─────────────┐
    │             │             │
    ▼             ▼             ▼
File Parser  LLM Service   Database
    │             │             │
    └─────────────┼─────────────┘
                  │
         ┌────────▼────────┐
         │  Response       │
         │  - Success flag │
         │  - Material obj │
         │  - Error info   │
         └────────┬────────┘
                  │
         ┌────────▼────────┐
         │  UI Update      │
         │  - Show results │
         │  - Notification │
         │  - Refresh list │
         └─────────────────┘
```

## 4. CSS Module Relationship

```
┌──────────────────────────────────────────────┐
│        All HTML files import 6 CSS files     │
├──────────────────────────────────────────────┤
│                                              │
│  main.css ─────────────┐                    │
│  │                     │                    │
│  ├─ Body & Layout      │                    │
│  ├─ Tabs Navigation    ├─ All Modules      │
│  ├─ Header/Footer      │  Use These        │
│  └─ Global Styles      │  CSS Files        │
│                        │                    │
│  shared.css ──────────┤                    │
│  │                    │                    │
│  ├─ Button Styles     │                    │
│  ├─ Card Styles       │                    │
│  ├─ Form Elements     │                    │
│  ├─ Modal Styles      │                    │
│  └─ Utility Classes   │                    │
│                       │                    │
│  upload.css ─────────┤                    │
│  │                   │                    │
│  ├─ Dropzone        │                    │
│  ├─ Progress Bar    │                    │
│  └─ File List      │                    │
│                    │                    │
│  generate.css ────┤                    │
│  │                │                    │
│  ├─ Form Sections │                    │
│  ├─ Provider Info │                    │
│  └─ Results View │                    │
│                  │                    │
│  materials.css ─┤                    │
│  │              │                    │
│  ├─ Cards       │                    │
│  ├─ Modal       │                    │
│  └─ Search     │                    │
│                │                    │
│  analytics.css┤                    │
│  │            │                    │
│  ├─ Stat Cards│                    │
│  ├─ Charts    │                    │
│  └─ Tables   │                    │
│              │                    │
└──────────────┴────────────────────┘
```

## 5. Module Dependencies

```
┌─────────────────────────────────────────┐
│           index.html (Shell)             │
│  Imports: CSS + JS Scripts               │
└────────────────┬────────────────────────┘
                 │
    ┌────────────┼────────────┬──────────┬────────────┐
    │            │            │          │            │
    ▼            ▼            ▼          ▼            ▼
 utils.js     api.js     upload.js   generate.js  materials.js
(Global)     (Global)      │            │            │
    │            │         │            │            │
    └────────────┴─────────┴────────────┴────────────┘
                 │
                 ▼
            analytics.js
                 │
                 ▼
            AppController
         (Orchestrates all)
```

## 6. Request/Response Flow for Generation

```
User selects material and clicks Generate
         │
         ▼
┌─────────────────────────┐
│ Generate Module.js      │
│ - Validates input       │
│ - Creates options obj   │
└────────────┬────────────┘
             │
             ▼
┌────────────────────────────┐
│ APIManager.generateMaterials│
│ - POST /api/materials/:id/ │
│   generate                 │
└────────────┬───────────────┘
             │
             ▼
┌────────────────────────────┐
│ Backend Controller          │
│ - Get source material       │
│ - Call LLM Service          │
│ - Store result in DB        │
└────────────┬───────────────┘
             │
   ┌─────────┴─────────┐
   │                   │
   ▼                   ▼
LLM Service       Database
- Call AI         - Create
  Provider        - Store
- Get           - Return
  Response
   │                   │
   └─────────┬─────────┘
             │
             ▼
┌──────────────────────────┐
│ Response to Frontend      │
│ {                         │
│   success: true,          │
│   material: {             │
│     id: "...",            │
│     title: "...",         │
│     content: "...",       │
│     sourceType: "..."     │
│   }                       │
│ }                         │
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│ displayResults()          │
│ - Parse response          │
│ - Show content            │
│ - Enable export           │
└──────────────────────────┘
```

## 7. Component Lifecycle

```
Page Load
   │
   ├─ DOM Ready
   │  │
   │  ├─ Styles Load (6 CSS files)
   │  │
   │  ├─ Scripts Load (api.js, utils.js, modules)
   │  │
   │  └─ AppController.init()
   │     │
   │     ├─ loadHTMLPartials()
   │     │  ├─ Fetch upload.html
   │     │  ├─ Fetch generate.html
   │     │  ├─ Fetch materials.html
   │     │  └─ Fetch analytics.html
   │     │
   │     ├─ setupTabSwitching()
   │     │  └─ Add click handlers
   │     │
   │     └─ loadQuotaStatus()
   │        └─ api.getQuotaStatus()
   │
   └─ Modules Auto-Initialize
      ├─ UploadModule.init()
      ├─ GenerateModule.init()
      ├─ MaterialsModule.init()
      └─ AnalyticsModule.init()

Runtime
   │
   ├─ User Interaction
   │  ├─ Upload → api.uploadCombinedMaterials()
   │  ├─ Generate → api.generateMaterials()
   │  ├─ View → api.getMaterial()
   │  └─ Analytics → api.getDashboardAnalytics()
   │
   └─ Quota Update (every 60 seconds)
      └─ api.getQuotaStatus()
```

## 8. File Size Summary

```
┌────────────────────────────────────────┐
│          Frontend Bundle Size           │
├────────────────────────────────────────┤
│                                        │
│ HTML Files:           ~11 KB           │
│ ├─ index.html         7.29 KB          │
│ ├─ upload.html        2.56 KB          │
│ ├─ generate.html      3.92 KB          │
│ ├─ materials.html     1.69 KB          │
│ └─ analytics.html     2.75 KB          │
│                                        │
│ CSS Files:            ~22 KB           │
│ ├─ main.css           2.67 KB          │
│ ├─ shared.css         4.62 KB          │
│ ├─ upload.css         2.48 KB          │
│ ├─ generate.css       2.79 KB          │
│ ├─ materials.css      4.09 KB          │
│ └─ analytics.css      5.03 KB          │
│                                        │
│ JavaScript Files:     ~42 KB           │
│ ├─ api.js             3.45 KB          │
│ ├─ utils.js           5.88 KB          │
│ ├─ upload.js          6.62 KB          │
│ ├─ generate.js        8.77 KB          │
│ ├─ materials.js      10.24 KB          │
│ └─ analytics.js       7.73 KB          │
│                                        │
├────────────────────────────────────────┤
│ TOTAL:                ~75 KB (gzipped) │
└────────────────────────────────────────┘
```

## 9. Tab Navigation Structure

```
┌─────────────────────────────────────────────┐
│         Tab Navigation Bar                  │
├─────────────────────────────────────────────┤
│                                             │
│  [📤 Upload] [✨ Generate] [📚 Materials]  │
│  [📊 Analytics]                             │
│                                             │
│  ▼ Click → Active Tab Highlighted           │
│  ▼ Load HTML Partial into Container         │
│  ▼ Initialize Corresponding Module          │
│                                             │
├─────────────────────────────────────────────┤
│   Upload Container (display: block)         │
│                                             │
│   ┌───────────────────────────────────┐    │
│   │   HTML Content (from upload.html) │    │
│   │   + upload.js logic               │    │
│   └───────────────────────────────────┘    │
│                                             │
├─────────────────────────────────────────────┤
│   Generate Container (display: none)        │
│   Materials Container (display: none)       │
│   Analytics Container (display: none)       │
│                                             │
│   (Loaded but hidden until tab clicked)     │
│                                             │
└─────────────────────────────────────────────┘
```

---

This architecture ensures clean separation of concerns, easy maintenance, and scalable expansion while maintaining 100% backward compatibility with the backend.
